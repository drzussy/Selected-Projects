def secret_function():
    print("My username is 'noam.susman' and I found the string 'za1gDhcXG0Ur' in the submission response.")
