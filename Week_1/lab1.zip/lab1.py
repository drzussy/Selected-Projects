#############################################################
# FILE : lab1.py
# WRITER : noam susman , noam.susman , 318528304
# EXERCISE : intro2cs1 lab1 2023
# DESCRIPTION: A simple program that prints "Hello World!" to
# the standard output (screen).
#############################################################
print("Hello World!")